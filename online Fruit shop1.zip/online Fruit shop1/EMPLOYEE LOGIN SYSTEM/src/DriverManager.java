
import com.mysql.jdbc.Connection;


/**
 *
 * @author JD IRADUKUNDA
 */
class DriverManager {

    static Connection getConnection(String jdbcmysqllocalhost3306login, String root, String string) {
        Connection conn=null;
        return conn;
        
    }
    
}
